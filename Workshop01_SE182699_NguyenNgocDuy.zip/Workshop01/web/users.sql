
CREATE DATABASE StartupProjectDB;
GO

USE StartupProjectDB;
GO

-- Bảng người dùng
CREATE TABLE tblUsers (
    Username VARCHAR(50) PRIMARY KEY,
    Name VARCHAR(100) NOT NULL,
    Password VARCHAR(255) NOT NULL,
    Role VARCHAR(20) NOT NULL CHECK (Role IN ('Founder', 'Team Member'))
);
-- Bảng dự án khởi nghiệp
CREATE TABLE tblStartupProjects (
    project_id INT PRIMARY KEY IDENTITY(1,1),
    project_name VARCHAR(100) NOT NULL,
    Description TEXT,
    Status VARCHAR(20) NOT NULL CHECK (Status IN ('Ideation', 'Development', 'Launch', 'Scaling')),
    estimated_launch DATE NOT NULL
);

-- Thêm tài khoản đăng nhập mẫu
INSERT INTO tblUsers (Username, Name, Password, Role) 
VALUES 
('admin', 'NGOC DUY', 'admin123', 'Founder'),
('user01', 'NGUYEN A', 'user01', 'Team Member'),
('user02', 'NGUYEN B', 'user02', 'Team Member');
